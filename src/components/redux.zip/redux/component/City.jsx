import React from 'react';
import { useState } from 'react';
import './Multi.css';

function City() {

const [name, setName]= useState('');
const [city, setCity]= useState('Mumbai');

const handleSubmit = () => {
    console.log({
        name,
        city
    });
};

    return(
        <div className='mainCity'>
            <div className='cityPerson'>
                <h1>Name</h1>
                <input type="text" placeholder='Enter city name' 
                value={name}
                onChange={(e) => setName(e.target.value)}
                />
            </div>

            <div className='city'>
                <h1>City </h1>
                <select value={city}
                onChange={(e) => setCity(e.target.value)}>
                    <option value="Mumbai">Mumbai</option>
                    <option value="New Delhi">New Delhi</option>
                    <option value="Noida">Noida</option>
                    <option value="Pune">Pune</option>
                    <option value="Bangalore">Bangalore</option>
                </select>
            </div>
            <button onClick={handleSubmit}>
                Send
            </button>
            

        </div>
    )
}

export default City;