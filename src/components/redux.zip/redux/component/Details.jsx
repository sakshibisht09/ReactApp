import React from 'react';
import './Multi.css';

function Details() {

    return(
        <div className='Details'>
            <h1>
                Wellcome, Redux
            </h1>

            <h2>Name:- </h2>
            <h3>City:- </h3>

        </div>
    )
}

export default Details;